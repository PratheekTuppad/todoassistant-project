require('dotenv').config();
const express = require('express');
const cors = require('cors');
const { createClient } = require('@supabase/supabase-js');
const axios = require('axios');

const app = express();
app.use(cors());
app.use(express.json());

const supabaseUrl = process.env.SUPABASE_URL;
const supabaseKey = process.env.SUPABASE_KEY;
const openaiApiKey = process.env.OPENAI_API_KEY;
const slackWebhookUrl = process.env.SLACK_WEBHOOK_URL;

const supabase = createClient(supabaseUrl, supabaseKey);

// Get all todos
app.get('/todos', async (req, res) => {
  const { data, error } = await supabase.from('todos').select('*').order('id', { ascending: true });
  if (error) return res.status(500).json({ error: error.message });
  res.json(data);
});

// Add new todo
app.post('/todos', async (req, res) => {
  const { title } = req.body;
  if (!title) return res.status(400).json({ error: 'Title is required' });

  const { data, error } = await supabase.from('todos').insert([{ title, completed: false }]).select().single();
  if (error) return res.status(500).json({ error: error.message });
  res.json(data);
});

// Update a todo
app.put('/todos/:id', async (req, res) => {
  const { id } = req.params;
  const { title, completed } = req.body;

  try {
    const { data, error } = await supabase
      .from('todos')
      .update({ title, completed })
      .eq('id', id)
      .select()
      .single();

    if (error) throw error;
    res.json(data);
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
});

// Delete a todo
app.delete('/todos/:id', async (req, res) => {
  const { id } = req.params;
  const { error } = await supabase.from('todos').delete().eq('id', id);
  if (error) return res.status(500).json({ error: error.message });
  res.json({ message: 'Todo deleted' });
});

// Summarize todos and send to Slack with OpenAI, fallback on 429 errors
app.post('/summarize', async (req, res) => {
  try {
    // Fetch pending todos (not completed)
    const { data: todos, error } = await supabase.from('todos').select('title').eq('completed', false);
    if (error) return res.status(500).json({ error: error.message });
    if (todos.length === 0) return res.status(200).json({ message: 'No pending todos to summarize.' });

    // Prepare prompt for OpenAI
    const todoList = todos.map((todo, i) => `${i + 1}. ${todo.title}`).join('\n');
    const prompt = `Summarize the following to-do list items briefly:\n${todoList}`;

    // Call OpenAI API
    const response = await axios.post(
      'https://api.openai.com/v1/chat/completions',
      {
        model: 'gpt-3.5-turbo',
        messages: [{ role: 'user', content: prompt }],
        max_tokens: 150,
      },
      {
        headers: { Authorization: `Bearer ${openaiApiKey}` },
      }
    );

    const summary = response.data.choices[0].message.content;

    // Send summary to Slack
    await axios.post(slackWebhookUrl, { text: summary });

    return res.json({ message: '✅ Summary sent to Slack (with OpenAI)', summary });
  } catch (err) {
    // Handle 429 rate limit error from OpenAI gracefully
    if (err.response && err.response.status === 429) {
      // Fallback: Send plain todos list summary without OpenAI
      const { data: todos, error } = await supabase.from('todos').select('title').eq('completed', false);
      if (error) return res.status(500).json({ error: error.message });
      if (todos.length === 0) return res.status(200).json({ message: 'No pending todos to summarize.' });

      const todoList = todos.map((todo, i) => `${i + 1}. ${todo.title}`).join('\n');
      const fallbackSummary = `📝 *Pending Todos Summary*\n${todoList}`;

      try {
        await axios.post(slackWebhookUrl, { text: fallbackSummary });
        return res.json({ message: '✅ Summary sent to Slack (without OpenAI due to rate limit)', summary: fallbackSummary });
      } catch (fallbackErr) {
        return res.status(500).json({ error: fallbackErr.message });
      }
    }

    // Other errors
    res.status(500).json({ error: err.message });
  }
});

// Start server
const PORT = process.env.PORT || 4000;
app.listen(PORT, () => {
  console.log(`Server listening on port ${PORT}`);
});
